Title: _printf
Description: Making my own printf function

Example: _printf("%s", hello)";
Example output: hello
